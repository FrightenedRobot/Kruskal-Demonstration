package View;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import Model.Model;
import Model.Edge;

/**
 * Class for viewing the model for debugging purposes
 */
public final class ConsoleView {

    public static int COLUMNLENGTH = 4;
    private Model graph;

    public ConsoleView(Model graph) {
        this.graph = graph;
    }


  public void initialModel() {
      System.out.println("Sort Edges:");
      for (Edge e: graph.getSortedEdges()) {
          System.out.println(e.toString() + " (" + e.getWeight() + ")");
      }
      System.out.println("MST:()");
  }

  public void kruskal() {
      int ctr = 0;
      Set<Edge> mst = new HashSet<>();
      List<Edge> sortedEdges = graph.getSortedEdges();
      while(mst.size() < graph.vertexSet().size() - 1) {
          Edge e = sortedEdges.get(ctr);
          mst.add(e);
          System.out.println("Choose Edge: " + e.toString() + " (" + e.getWeight() + ")");
          ctr++;
      }
      System.out.println("STOP");
      System.out.print("MST: {");
      for (Edge e: mst) {
          System.out.print(e.toString() + ", ");
      }
      System.out.println("}");
  }



    /**
     * print the text representation of the model
     */
    public void initialize() {
        this.initialModel();
        this.kruskal();
    }

}





