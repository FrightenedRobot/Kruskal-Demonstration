package util;

import Model.Model;


public interface GraphBuilder {
    /**
     * Constructs an actual composition, given the notes that have been added
     * @return The new composition
     */
    Model build();

    /**
     * adds a new vertex to the graph
     * @param vertex The vertex to be added
     * @return This builder
     */
    GraphBuilder addVertex(String vertex );

    /**
     * Adds a new edge to the piece
     * @param source The source vertex of the edge
     * @param target The target vertex of the edge
     * @param weight the weight of the edge
     * @return this builder
     */
    GraphBuilder addEdge(String source, String target, int weight);
}
