package util;

import java.util.NoSuchElementException;
import java.util.Scanner;
import Model.Model;
/**
 * Created by Jackson on 12/15/15.
 */
public class GraphReader {
        public static Model parseFile(Readable readable) {
            Model m = new Model();
            Scanner scanner = new Scanner(readable);
            while (scanner.hasNext()) {
                String lineType = scanner.next();
                switch (lineType) {
                    case "vertex":
                        try {
                            m.addVertex(scanner.next());
                        } catch (NoSuchElementException e) {
                            throw new IllegalArgumentException("Malformed vertex line: " + scanner.nextLine());
                        }
                        break;
                    case "edge":
                        try {
                            String source = scanner.next();
                            String target = scanner.next();
                            int weight = scanner.nextInt();
                            m.addEdge(source, target, weight);
                        } catch (NoSuchElementException e) {
                            throw new IllegalArgumentException("Malformed edge line: " + scanner.nextLine());
                        }
                        break;
                    default:
                        throw new IllegalArgumentException("Bad line type: " + lineType);
                }
            }

            return m;
        }
}
