package Main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import Model.Model;
import View.ConsoleView;
import util.GraphReader;



/**
 * Created by Jackson on 12/15/15.
 */
public class Demo {
    public static void main(String args[]) {
        Model graph = null;
        try {
            graph = GraphReader.parseFile(new FileReader(new File("input.txt")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        ConsoleView view = new ConsoleView(graph);
        view.initialize();
    }
}
