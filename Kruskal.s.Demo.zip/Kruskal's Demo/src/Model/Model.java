package Model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Jackson on 12/15/15.
 */
public class Model{

    private Set<String> nodes;
    private Set<Edge> edges;

    public Model() {
        this.nodes = new HashSet<>();
        this.edges = new HashSet<>();
    }


    public void setEdgeWeight(Edge edge, int v) {
        edge.setWeight(v);
    }

    public Set<Edge> getAllEdges(String c, String v1) {
        Set<Edge> allEdges = new HashSet<>();
        if (this.nodes.contains(c) && this.nodes.contains(v1)) {
            for (Edge e: edges) {
                if (e.getSource().equals(c) && e.getTarget().equals(v1) ||
                        e.getSource().equals(v1) && e.getTarget().equals(c)) {
                    allEdges.add(e);
                }
            }
        }
        else {
            return null;
        }
        return allEdges;
    }

    public Edge getEdge(String c, String v1) {
        if (this.nodes.contains(c) && this.nodes.contains(v1)) {
            for (Edge e: edges) {
                if (e.getSource().equals(c) && e.getTarget().equals(v1) ||
                        e.getSource().equals(v1) && e.getTarget().equals(c)) {
                    return e;
                }
            }
            return null;
        }
        else {
            return null;
        }
    }

    public void addEdge(String c, String v1, int weight) {
        this.edges.add(new Edge(c, v1, weight));
        this.nodes.add(c);
        this.nodes.add(v1);
    }

    public void addVertex(String c) {
        this.nodes.add(c);
    }

    public boolean containsEdge(String c, String v1) {
        for (Edge e: edges){
            if (e.getTarget().equals(c) || e.getSource().equals(c)) {
                return true;
            }
        }
        return false;
    }

    public boolean containsVertex(String c) {
        return nodes.contains(c);
    }

    public Set<Edge> edgeSet() {
        return this.edges;
    }

    public Set<Edge> edgesOf(String c) {
        Set<Edge> temp = new HashSet<>();
        for (Edge e: edges) {
            if (e.getTarget().equals(c) || e.getSource().equals(c)) {
                temp.add(e);
            }
        }
        return temp;
    }

    public boolean removeAllEdges(String c, String v1) {
        boolean b = false;

        for (Edge e: edges) {
            if (e.getTarget().equals(c) || e.getSource().equals(c)) {
                edges.remove(e);
                b = true;
            }
        }
        return b;
    }

    public Edge removeEdge(String c, String v1) {
        for (Edge e: edges) {
            if (e.getTarget().equals(c) || e.getSource().equals(c)) {
                edges.remove(e);
                return e;
            }
        }
        return null;
    }

    public boolean removeVertex(String c) {
        return nodes.remove(c);
    }

    public int getEdgeWeight(Edge edge) {
        return edge.getWeight();
    }

    public String getEdgeTarget(Edge edge) {
        return edge.getTarget();
    }

    public String getEdgeSource(Edge edge) {
        return edge.getTarget();
    }

    public boolean removeEdge(Edge edge) {
        return edges.remove(edge);
    }

    public boolean containsEdge(Edge edge) {
        return this.edges.contains(edge);
    }

    public boolean addEdge(String c, String v1, Edge edge) {
        return edges.add(edge) && nodes.add(c) && nodes.add(v1);
    }

    public Set<String> vertexSet() {
        return this.nodes;
    }

    public List<Edge> getSortedEdges() {
        List<Edge> sorted = new ArrayList(this.edges);
        Collections.sort(sorted);
        return sorted;
    }

}
